// Lấy các phần tử từ HTML
let pressButton = document.getElementById('pressButton');
let resetButton = document.getElementById('resetButton');
let counterDisplay = document.getElementById('counter');
let pressCount = 0;

// Hàm để gửi giá trị pressCount đến ESP32 và nhận lại dữ liệu mảng
function sendPressCountToESP32(count) {
    fetch('/receive', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ pressCount: count })  // Gửi giá trị pressCount dưới dạng JSON
    })
    .then(response => response.json())  // Nhận phản hồi JSON từ ESP32
    .then(data => {
        // Kiểm tra xem dữ liệu có chứa mảng `array` hay không
        if (data.array && Array.isArray(data.array)) {
            const receivedArray = data.array;  // Lấy mảng từ đối tượng JSON

            // Hiển thị giá trị hiện tại (phần tử đầu tiên của mảng)
            document.getElementById("receivedValue").innerText = `${receivedArray[0]}`;

            // Tạo danh sách các giá trị đo được trước đó
            const previousValuesContainer = document.getElementById("previousValues");
            previousValuesContainer.innerHTML = '<p>Giá trị đo được trước đó:</p>';
            for (let i = 1; i < receivedArray.length; i++) {
                const valueElement = document.createElement("p");
                valueElement.innerText = `${i}: ${receivedArray[i]}`;
                previousValuesContainer.appendChild(valueElement);
            }
        } else {
            document.getElementById("receivedValue").innerText = "Dữ liệu không hợp lệ từ ESP32";
        }
    })
    .catch(error => {
        console.error('Error:', error);
        document.getElementById("receivedValue").innerText = "Lỗi khi tải dữ liệu từ ESP32";
    });
}

// Khi người dùng nhấn giữ nút
pressButton.addEventListener('mousedown', () => {
    pressButton.textContent = 'Release';
    pressCount++;
    counterDisplay.textContent = `Press Counter: ${pressCount}`;

    // Gửi giá trị pressCount đến ESP32 và cập nhật hiển thị
    sendPressCountToESP32(pressCount);
});

// Khi người dùng thả nút
pressButton.addEventListener('mouseup', () => {
    pressButton.textContent = 'Press';
});

// Nút để xóa số lần nhấn
resetButton.addEventListener('click', () => {
    pressCount = 0;
    counterDisplay.textContent = `Press Counter: ${pressCount}`;
    sendPressCountToESP32(pressCount); // Gửi lại giá trị sau khi reset để cập nhật từ ESP32
});
